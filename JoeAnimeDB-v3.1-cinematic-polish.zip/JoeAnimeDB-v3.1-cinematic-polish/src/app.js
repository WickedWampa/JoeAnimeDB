
const STORAGE_KEY = 'joeanime-db-v2-prototype';
const STATUSES = ['All', 'Watched', 'Watching', 'Rewatching', 'Planned', 'Paused', 'Dropped'];
const MANUAL_SEARCH_FIXES = {
  "Bleach TYBW": "Bleach Sennen Kessen-hen",
  "Slime S2": "Tensei shitara Slime Datta Ken 2nd Season",
  "Slime S3": "Tensei shitara Slime Datta Ken 3rd Season",
  "That Time I Got Reincarnated as a Slime": "Tensei shitara Slime Datta Ken",
  "Reincarnated as a Slime Movie": "Tensei shitara Slime Datta Ken Movie",
  "Slime Diaries": "Tensura Nikki",
  "Mushoku Tensei": "Mushoku Tensei: Isekai Ittara Honki Dasu",
  "Mushoku Tensei S2": "Mushoku Tensei II",
  "Solo Leveling S2": "Solo Leveling Season 2",
  "SAO II": "Sword Art Online II",
  "SAO Alicization": "Sword Art Online: Alicization",
  "SAO War of Underworld": "Sword Art Online: Alicization - War of Underworld",
  "Fullmetal Alchemist Brotherhood": "Fullmetal Alchemist: Brotherhood",
  "Re:ZERO": "Re:Zero kara Hajimeru Isekai Seikatsu",
  "Code Geass": "Code Geass: Hangyaku no Lelouch",
  "Fate UBW": "Fate/stay night: Unlimited Blade Works",
  "Fate Zero": "Fate/Zero",
  "G Gundam": "Mobile Fighter G Gundam",
  "Gundam Wing": "Mobile Suit Gundam Wing"
};

let seed = window.JOEANIMEDB_SEED;
let state = loadState();
let currentView = 'rankings';
let displayMode = 'poster';
let searchText = '';
let statusFilter = 'All';
let sortMode = 'rank';
let cancelSync = false;

function clone(x){ return JSON.parse(JSON.stringify(x)); }
function loadState(){ try { return JSON.parse(localStorage.getItem(STORAGE_KEY)) || clone(seed); } catch { return clone(seed); } }
function saveState(){ localStorage.setItem(STORAGE_KEY, JSON.stringify(state)); }
function animeList(){ return Array.isArray(state.anime) ? state.anime : []; }
function n(v){ const x = Number(v); return Number.isFinite(x) ? x : 0; }
function avg(values){ return values.length ? values.reduce((s,v)=>s+n(v),0)/values.length : 0; }
function esc(s){ return String(s ?? '').replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#039;'}[c])); }
function initials(title){ return String(title || '?').split(/\s+/).filter(Boolean).slice(0,2).map(x=>x[0]).join('').toUpperCase(); }
function byCount(items){ const m={}; items.forEach(x=>{ if(x) m[x]=(m[x]||0)+1; }); return Object.entries(m).sort((a,b)=>b[1]-a[1]); }
function cover(anime, cls='poster'){ const src = anime.cover || ''; const fallback = esc(initials(anime.title)); return `<div class="${cls}">${src ? `<img src="${esc(src)}" onerror="this.remove();this.parentElement.textContent='${fallback}'">` : fallback}</div>`; }
function cleanSearchTitle(title){ return MANUAL_SEARCH_FIXES[title] || title.replace(/\bS2\b/gi,'Season 2').replace(/\bS3\b/gi,'Season 3').trim(); }
function sleep(ms){ return new Promise(r=>setTimeout(r,ms)); }

function layout(title, subtitle, extra=''){
  return `<div class="pageHead"><div><h1>${title}</h1><p>${subtitle}</p></div>${extra}</div>`;
}

function stats(){
  const list = animeList();
  const episodes = list.reduce((s,a)=>s+n(a.episodeCount || a.episodesWatched),0);
  const rewatches = list.reduce((s,a)=>s+n(a.rewatches),0);
  const topStudio = byCount(list.map(a=>a.studio))[0]?.[0] || '—';
  return `<section class="statStrip">
    <div class="stat"><strong>${list.length}</strong><span>Total Anime</span></div>
    <div class="stat"><strong>${avg(list.map(a=>a.rating)).toFixed(2)}</strong><span>Avg Joe Score</span></div>
    <div class="stat"><strong>${Math.round(episodes*24/60).toLocaleString()}</strong><span>Est. Hours</span></div>
    <div class="stat"><strong>${rewatches}</strong><span>Rewatches</span></div>
    <div class="stat"><strong>${esc(topStudio).slice(0,16)}</strong><span>Top Studio</span></div>
  </section>`;
}

function filtered(){
  const q = searchText.trim().toLowerCase();
  let list = animeList().filter(a => {
    let quick = true;
    if(q === '__top10') quick = n(a.finalRank) <= 10;
    else if(q === '__favorites') quick = !!a.favoriteRank || n(a.finalRank) <= 22;
    else if(q === '__rewatched') quick = n(a.rewatches) > 0;
    const hay = [a.title,a.status,a.studio,a.notes,a.priority,a.confidence,a.type,a.year,...(a.genres||[])].join(' ').toLowerCase();
    return (q.startsWith('__') ? quick : (!q || hay.includes(q))) && (statusFilter === 'All' || a.status === statusFilter);
  });
  list.sort((a,b)=>{
    if(sortMode==='title') return a.title.localeCompare(b.title);
    if(sortMode==='score') return n(b.rating)-n(a.rating);
    if(sortMode==='studio') return String(a.studio).localeCompare(String(b.studio)) || a.title.localeCompare(b.title);
    if(sortMode==='rewatches') return n(b.rewatches)-n(a.rewatches);
    return n(a.finalRank)-n(b.finalRank);
  });
  return list;
}

function controls(){
  return `<section class="controls">
    <input id="localSearch" placeholder="Search anime, studio, genre..." value="${searchText.startsWith('__')?'':esc(searchText)}">
    <select id="statusFilter">${STATUSES.map(s=>`<option ${s===statusFilter?'selected':''}>${s}</option>`).join('')}</select>
    <select id="sortSelect">
      <option value="rank">Sort: Rank</option><option value="score">Sort: Score</option><option value="title">Sort: Title</option><option value="studio">Sort: Studio</option><option value="rewatches">Sort: Rewatches</option>
    </select>
    <button id="addBtn">Add Anime</button>
  </section>
  <section class="chips">
    <button data-chip="">All</button><button data-chip="__top10">🏆 Top 10</button><button data-chip="__favorites">💗 Favorites</button><button data-chip="__rewatched">↻ Rewatched</button><button data-chip="MAPPA">MAPPA</button><button data-chip="Pierrot">Pierrot</button><button data-chip="Isekai">Isekai</button>
  </section>`;
}

function viewToggle(){
  return `<div class="viewToggle"><button data-mode="poster" class="${displayMode==='poster'?'active':''}">Poster Grid</button><button data-mode="list" class="${displayMode==='list'?'active':''}">Detailed List</button></div>`;
}

function posterCard(a){
  const ribbon = n(a.finalRank)===1 ? 'GOAT' : n(a.finalRank)<=10 ? `#${a.finalRank}` : n(a.rewatches)>=3 ? 'Rewatch King' : '';
  const community = a.communityScore ? `MAL ${Number(a.communityScore).toFixed(2)}` : '';
  const eps = a.episodeCount ? `${a.episodeCount} eps` : '';
  return `<article class="animeCard" data-open="${a.id}">
    ${cover(a,'poster')}
    ${ribbon ? `<span class="ribbon">${ribbon}</span>` : ''}
    <span class="scoreBadge">★ ${n(a.rating).toFixed(1)}</span>
    <div class="cardShade"></div>
    <div class="hoverSynopsis">${esc((a.synopsis || '').slice(0, 190))}${a.synopsis && a.synopsis.length > 190 ? '…' : ''}</div>
    <div class="cardInfo">
      <h3>${esc(a.title)}</h3>
      <p>#${a.finalRank} · ${esc(a.studio || 'Unknown')}</p>
      <div class="miniMeta">
        ${eps ? `<span>${esc(eps)}</span>` : ''}
        ${a.year ? `<span>${esc(a.year)}</span>` : ''}
        ${community ? `<span>${esc(community)}</span>` : ''}
      </div>
      <div class="tags">${(a.genres||[]).slice(0,3).map(g=>`<span>${esc(g)}</span>`).join('')}</div>
    </div>
  </article>`;
}

function listTable(list){
  return `<div class="tableWrap"><table class="rankTable"><thead><tr><th>#</th><th>Anime</th><th>Score</th><th>Type</th><th>Episodes</th><th>Studio</th><th>Genres</th><th>Rewatch</th><th>Status</th></tr></thead><tbody>
  ${list.map(a=>`<tr data-open="${a.id}"><td>${a.finalRank}</td><td><div class="animeCell">${cover(a,'thumb')}<div><strong>${esc(a.title)}</strong><p>${esc(a.year||'')} ${a.year?'·':''} ${esc(a.type||'TV')}</p></div></div></td><td>★ ${n(a.rating).toFixed(2)}</td><td><span class="pill">${esc(a.type||'TV')}</span></td><td>${a.episodeCount||'—'}</td><td class="purple">${esc(a.studio||'Unknown')}</td><td>${esc((a.genres||[]).slice(0,3).join(', '))}</td><td>${n(a.rewatches)}</td><td><span class="status">${esc(a.status)}</span></td></tr>`).join('')}
  </tbody></table></div>`;
}

function renderRankings(){
  document.getElementById('view').innerHTML = layout('Rankings', 'Your definitive ranked anime command center.', viewToggle()) + stats() + controls() + `<div id="results"></div>`;
  bindListControls();
  renderResults();
}

function renderResults(){
  const node = document.getElementById('results'); if(!node) return;
  const list = filtered();
  node.innerHTML = displayMode === 'list' ? listTable(list) : `<section class="posterGrid">${list.map(posterCard).join('')}</section>`;
  bindOpen();
}

function row(a){ return `<div class="row" data-open="${a.id}"><span>#${a.finalRank}</span><strong>${esc(a.title)}</strong><em>★ ${n(a.rating).toFixed(1)}</em></div>`; }

function renderHome(){
  const top = [...animeList()].sort((a,b)=>n(a.finalRank)-n(b.finalRank)).slice(0,6);
  const current = animeList().filter(a=>a.status==='Watching'||a.status==='Rewatching').slice(0,5);
  const rewatchKings = animeList().filter(a=>n(a.rewatches)>0).sort((a,b)=>n(b.rewatches)-n(a.rewatches)).slice(0,5);
  const random = animeList()[Math.floor((Date.now()/86400000)%animeList().length)] || top[0];
  document.getElementById('view').innerHTML =
    `<section class="dashboardHero">
      <div>
        <p class="eyebrow">Welcome back, Joe</p>
        <h1>What are we watching?</h1>
        <p>Your 108-title anime command center is loaded with posters, metadata, rankings, and your own scores.</p>
        <div class="actions">
          <button onclick="currentView='rankings';renderCurrent()">Open Rankings</button>
          <button onclick="openDetail(${random.id})">Random Pick</button>
        </div>
      </div>
      <div class="heroPick" data-open="${random.id}">
        ${cover(random,'heroPoster')}
        <div><strong>Daily Pick</strong><h2>${esc(random.title)}</h2><p>★ ${n(random.rating).toFixed(1)} · #${random.finalRank}</p></div>
      </div>
    </section>` +
    stats() +
    `<section class="threeCol">
      <div class="panel"><h2>Top Rated</h2>${top.map(row).join('')}</div>
      <div class="panel"><h2>Continue Watching</h2>${current.length?current.map(row).join(''):'<p class="muted">Nothing marked watching yet.</p>'}</div>
      <div class="panel"><h2>Rewatch Kings</h2>${rewatchKings.length?rewatchKings.map(row).join(''):'<p class="muted">No rewatches logged yet.</p>'}</div>
    </section>
    <section class="panel"><h2>Top 6 Poster Wall</h2><div class="posterGrid small">${top.map(posterCard).join('')}</div></section>`;
  bindOpen();
}

function renderBars(kind){
  const data = kind==='studios' ? byCount(animeList().map(a=>a.studio)) : byCount(animeList().flatMap(a=>a.genres||[]));
  const max = data[0]?.[1] || 1;
  document.getElementById('view').innerHTML = layout(kind==='studios'?'Studio Center':'Genre Explorer', kind==='studios'?'Studio breakdown.':'Genre breakdown.') + stats() + `<section class="panel">${data.map(([name,count])=>`<div class="barRow"><strong>${esc(name)}</strong><div class="bar"><div style="width:${count/max*100}%"></div></div><span>${count}</span></div>`).join('')}</section>`;
}


function renderCollections(){
  const collections = [
    ['GOATs', animeList().filter(a=>n(a.finalRank)<=10), 'The sacred top 10.'],
    ['Must Watch / Favorites', animeList().filter(a=>String(a.priority||'').includes('Must') || n(a.finalRank)<=22), 'Highest priority and favorites.'],
    ['Rewatch Kings', animeList().filter(a=>n(a.rewatches)>0).sort((a,b)=>n(b.rewatches)-n(a.rewatches)), 'Shows you went back to.'],
    ['MAPPA Zone', animeList().filter(a=>String(a.studio).includes('MAPPA')), 'All MAPPA entries.'],
    ['Isekai Shelf', animeList().filter(a=>(a.genres||[]).includes('Isekai')), 'Truck-kun adjacent greatness.'],
    ['Low Confidence to Verify', animeList().filter(a=>a.confidence==='Low'), 'Good ones to confirm/edit later.']
  ];
  document.getElementById('view').innerHTML = layout('Collections','Curated shelves based on your rankings and metadata.') +
    `<section class="collectionGrid">${collections.map(([name,items,desc])=>`
      <div class="collectionCard" data-collection="${esc(name)}">
        <h2>${esc(name)}</h2>
        <p>${esc(desc)}</p>
        <strong>${items.length} titles</strong>
        <div class="miniPosters">${items.slice(0,4).map(a=>cover(a,'miniPoster')).join('')}</div>
      </div>`).join('')}</section>
    <section id="collectionResults"></section>`;
  document.querySelectorAll('[data-collection]').forEach((card,idx)=>{
    card.onclick=()=>{
      const [name,items]=collections[idx];
      document.getElementById('collectionResults').innerHTML = `<div class="pageHead"><div><h1>${esc(name)}</h1><p>${items.length} titles</p></div></div><section class="posterGrid">${items.map(posterCard).join('')}</section>`;
      bindOpen();
    };
  });
}

function renderRecommendations(){
  const watchedGenres = byCount(animeList().flatMap(a=>a.genres||[])).slice(0,5).map(x=>x[0]);
  const lowConfidence = animeList().filter(a=>a.confidence==='Low').sort((a,b)=>n(b.rating)-n(a.rating)).slice(0,12);
  const hiddenGems = animeList().filter(a=>n(a.rating)>=8.4 && n(a.finalRank)>60).slice(0,12);
  const nextUp = [...new Set([...lowConfidence, ...hiddenGems])].slice(0,16);
  document.getElementById('view').innerHTML = layout('Recommendations','Smart picks based on your scores, genres, studios, and confidence levels.') +
    `<section class="recommendHero panel"><h2>Joe's Taste Profile</h2><p>Heavy lean toward ${watchedGenres.map(esc).join(', ')} with high scores for long-running hype, world-building, and action progression.</p></section>
    <section class="panel"><h2>Suggested to Verify / Revisit</h2><div class="posterGrid">${nextUp.map(posterCard).join('')}</div></section>`;
  bindOpen();
}

function renderStatsPage(){
  const studios = byCount(animeList().map(a=>a.studio)).slice(0,12);
  const genres = byCount(animeList().flatMap(a=>a.genres||[])).slice(0,12);
  const scores = {};
  animeList().forEach(a=>{ const bucket = Math.floor(n(a.rating)); scores[bucket]=(scores[bucket]||0)+1; });
  const scoreRows = Object.entries(scores).sort((a,b)=>Number(b[0])-Number(a[0]));
  const maxStudio = studios[0]?.[1] || 1;
  const maxGenre = genres[0]?.[1] || 1;
  const maxScore = Math.max(...Object.values(scores),1);
  document.getElementById('view').innerHTML = layout('Statistics','Analytics for your anime universe.') + stats() +
    `<section class="threeCol">
      <div class="panel"><h2>Studios</h2>${studios.map(([name,count])=>`<div class="barRow"><strong>${esc(name)}</strong><div class="bar"><div style="width:${count/maxStudio*100}%"></div></div><span>${count}</span></div>`).join('')}</div>
      <div class="panel"><h2>Genres</h2>${genres.map(([name,count])=>`<div class="barRow"><strong>${esc(name)}</strong><div class="bar"><div style="width:${count/maxGenre*100}%"></div></div><span>${count}</span></div>`).join('')}</div>
      <div class="panel"><h2>Score Distribution</h2>${scoreRows.map(([score,count])=>`<div class="barRow"><strong>${score}.x</strong><div class="bar"><div style="width:${count/maxScore*100}%"></div></div><span>${count}</span></div>`).join('')}</div>
    </section>`;
}


function renderTimeline(){
  const top = [...animeList()].sort((a,b)=>n(a.finalRank)-n(b.finalRank)).slice(0,18);
  const groups = [
    ['GOAT Era', top.slice(0,5)],
    ['Top Tier Run', top.slice(5,12)],
    ['Strong Queue', top.slice(12,18)]
  ];
  document.getElementById('view').innerHTML = layout('Timeline','A cinematic watch-history timeline shell. Later this can use real watched dates.') +
    `<section class="timeline">
      ${groups.map(([name,items])=>`
        <div class="timelineBlock">
          <div class="timelineDot"></div>
          <h2>${esc(name)}</h2>
          <div class="timelineCards">${items.map(a=>`
            <div class="timelineItem" data-open="${a.id}">
              ${cover(a,'miniPoster')}
              <div><strong>${esc(a.title)}</strong><p>#${a.finalRank} · ★ ${n(a.rating).toFixed(1)}</p></div>
            </div>`).join('')}</div>
        </div>`).join('')}
    </section>`;
  bindOpen();
}

function renderWrapped(){
  const list = animeList();
  const topGenre = byCount(list.flatMap(a=>a.genres||[]))[0] || ['—',0];
  const topStudio = byCount(list.map(a=>a.studio))[0] || ['—',0];
  const episodes = list.reduce((s,a)=>s+n(a.episodeCount||a.episodesWatched),0);
  const hours = Math.round(episodes*24/60);
  const top5 = [...list].sort((a,b)=>n(a.finalRank)-n(b.finalRank)).slice(0,5);
  document.getElementById('view').innerHTML = layout('Joe Anime Wrapped','Your anime taste summarized like a yearly recap.') +
    `<section class="wrappedHero">
      <div><span>Total Anime</span><strong>${list.length}</strong></div>
      <div><span>Estimated Hours</span><strong>${hours.toLocaleString()}</strong></div>
      <div><span>Top Genre</span><strong>${esc(topGenre[0])}</strong></div>
      <div><span>Top Studio</span><strong>${esc(topStudio[0])}</strong></div>
    </section>
    <section class="panel"><h2>Your Sacred Top 5</h2><div class="posterGrid small">${top5.map(posterCard).join('')}</div></section>
    <section class="wrappedQuote">“Bleach remains undefeated.”</section>`;
  bindOpen();
}

function renderCalendar(){
  const watching = animeList().filter(a=>a.status==='Watching'||a.status==='Rewatching');
  const days = ['Monday','Tuesday','Wednesday','Thursday','Friday','Saturday','Sunday'];
  document.getElementById('view').innerHTML = layout('Watch Calendar','A weekly release and watch-planning shell.') +
    `<section class="calendarGrid">
      ${days.map((day,i)=>`
        <div class="calendarDay">
          <h2>${day}</h2>
          ${(watching[i]?[watching[i]]:[]).map(a=>`
            <div class="calendarShow" data-open="${a.id}">
              ${cover(a,'miniPoster')}
              <div><strong>${esc(a.title)}</strong><p>Next episode</p></div>
            </div>`).join('') || '<p class="muted">Open slot</p>'}
        </div>`).join('')}
    </section>`;
  bindOpen();
}

function renderSettings(){
  document.getElementById('view').innerHTML = layout('Settings','Control themes, backups, and local app behavior.') +
    `<section class="settingsGrid">
      <div class="panel"><h2>Themes</h2><div class="chips">
        <button data-theme="">Cyber Default</button>
        <button data-theme="amoled">AMOLED</button>
        <button data-theme="purple">Purple</button>
        <button data-theme="bleachTheme">Bleach Gold</button>
      </div></div>
      <div class="panel"><h2>Backups</h2><p class="muted">Export your current app state, including synced posters and metadata.</p><button onclick="document.getElementById('exportBtn').click()">Export Backup</button></div>
      <div class="panel"><h2>Database</h2><p class="muted">Use Update Database to refresh posters, descriptions, studios, genres, and episode counts.</p><button onclick="document.getElementById('syncBtnTop').click()">Update Database</button></div>
    </section>`;
  document.querySelectorAll('[data-theme]').forEach(b=>b.onclick=()=>{
    document.body.className = b.dataset.theme;
    localStorage.setItem('joeanime-theme', b.dataset.theme);
  });
}

function renderAchievements(){
  const titles = animeList().map(a=>a.title);
  const rewatches = animeList().reduce((s,a)=>s+n(a.rewatches),0);
  const ach = [
    ['🏆','100 Anime Club',animeList().length>=100],
    ['🍓','Bleach Addict',animeList().some(a=>a.title==='Bleach'&&n(a.rewatches)>=5)],
    ['👑','Big Three Energy',titles.includes('Bleach')&&titles.includes('Naruto')&&titles.includes('One Piece')],
    ['🔁','Rewatch Machine',rewatches>=10],
    ['🔥','MAPPA Fanatic',animeList().filter(a=>String(a.studio).includes('MAPPA')).length>=5],
  ];
  document.getElementById('view').innerHTML = layout('Achievements','Trophies for your anime journey.') + `<section class="achGrid">${ach.map(([icon,name,done])=>`<div class="ach ${done?'done':''}"><b>${icon}</b><h3>${name}</h3><p>${done?'Unlocked':'Locked'}</p></div>`).join('')}</section>`;
}

function renderShrine(){
  const b = animeList().find(a=>a.title==='Bleach');
  const tybw = animeList().find(a=>a.title==='Bleach TYBW');
  document.getElementById('view').innerHTML = `<section class="shrine"><h1>BLEACH</h1><p>GOAT status. Arcs, TYBW, captains, openings, fights, and notes live here.</p><div class="shrineStats"><div><strong>#${b?.finalRank||1}</strong><span>All-time</span></div><div><strong>${b?.rewatches||5}x</strong><span>Rewatches</span></div><div><strong>${tybw?.rating||9.9}</strong><span>TYBW</span></div></div><button data-open="${b?.id}">Open Bleach</button></section>`;
  bindOpen();
}

function renderCurrent(){
  document.querySelectorAll('#tabs button').forEach(b=>b.classList.toggle('active',b.dataset.view===currentView));
  if(currentView==='home') renderHome();
  else if(currentView==='library'||currentView==='rankings') renderRankings();
  else if(currentView==='watching'){ statusFilter='Watching'; renderRankings(); }
  else if(currentView==='studios') renderBars('studios');
  else if(currentView==='genres') renderBars('genres');
  else if(currentView==='collections') renderCollections();
  else if(currentView==='recommendations') renderRecommendations();
  else if(currentView==='stats') renderStatsPage();
  else if(currentView==='timeline') renderTimeline();
  else if(currentView==='wrapped') renderWrapped();
  else if(currentView==='calendar') renderCalendar();
  else if(currentView==='settings') renderSettings();
  else if(currentView==='achievements') renderAchievements();
  else renderShrine();
}

function bindListControls(){
  document.querySelectorAll('[data-mode]').forEach(b=>b.onclick=()=>{ displayMode=b.dataset.mode; renderRankings(); });
  document.getElementById('localSearch').oninput=e=>{ searchText=e.target.value; document.getElementById('globalSearch').value=searchText; renderResults(); };
  document.getElementById('statusFilter').onchange=e=>{ statusFilter=e.target.value; renderResults(); };
  document.getElementById('sortSelect').value=sortMode;
  document.getElementById('sortSelect').onchange=e=>{ sortMode=e.target.value; renderResults(); };
  document.querySelectorAll('[data-chip]').forEach(b=>b.onclick=()=>{ searchText=b.dataset.chip; document.getElementById('globalSearch').value=searchText.startsWith('__') ? b.textContent.replace(/[🏆💗↻]/g,'').trim() : searchText; renderResults(); });
  document.getElementById('addBtn').onclick=addAnime;
}

function bindOpen(){ document.querySelectorAll('[data-open]').forEach(el=>el.onclick=()=>openDetail(Number(el.dataset.open))); }

function openDetail(id){
  const a = animeList().find(x=>x.id===id); if(!a) return;
  const community = a.communityScore ? Number(a.communityScore).toFixed(2) : '—';
  const diff = a.communityScore ? (n(a.rating)-n(a.communityScore)).toFixed(2) : '—';
  document.getElementById('modalBody').innerHTML = `<div class="detailHero">${cover(a,'detailPoster')}<div><p class="eyebrow">Rank #${a.finalRank}</p><h1>${esc(a.title)}</h1><p class="muted">${esc(a.studio||'Unknown')} · ${esc(a.type||'TV')} · ${esc(a.year||'')}</p><div class="detailStats"><div><strong>${n(a.rating).toFixed(1)}</strong><span>Joe</span></div><div><strong>${community}</strong><span>Community</span></div><div><strong>${diff}</strong><span>Difference</span></div><div><strong>${n(a.rewatches)}</strong><span>Rewatches</span></div></div><div class="tags">${[...(a.genres||[]),a.priority,a.confidence].filter(Boolean).map(x=>`<span>${esc(x)}</span>`).join('')}</div><p>${esc(a.synopsis||'')}</p><div class="actions">${a.trailerUrl?`<a class="button" target="_blank" href="${esc(a.trailerUrl)}">▶ Trailer</a>`:''}<button id="editToggle">✎ Edit Details</button></div></div></div><section id="editPanel" class="editPanel"><div class="editGrid"><label>Title<input id="mTitle" value="${esc(a.title)}"></label><label>Status<select id="mStatus">${['Watched','Watching','Rewatching','Planned','Paused','Dropped'].map(s=>`<option ${a.status===s?'selected':''}>${s}</option>`).join('')}</select></label><label>Joe Score<input id="mRating" type="number" step=".1" value="${n(a.rating)}"></label><label>Studio<input id="mStudio" value="${esc(a.studio||'')}"></label><label>Genres<input id="mGenres" value="${esc((a.genres||[]).join(', '))}"></label><label>Rewatches<input id="mRew" type="number" value="${n(a.rewatches)}"></label><label>Episodes<input id="mEpisodes" type="number" value="${n(a.episodeCount)}"></label><label>Cover URL<input id="mCover" value="${esc(a.cover||'')}"></label><label>Trailer URL<input id="mTrailer" value="${esc(a.trailerUrl||'')}"></label></div><label>Notes<textarea id="mNotes">${esc(a.notes||'')}</textarea></label><label>Synopsis<textarea id="mSynopsis">${esc(a.synopsis||'')}</textarea></label><div class="actions"><button id="saveModal">Save</button><button class="danger" id="deleteModal">Delete</button></div></section>`;
  document.getElementById('editToggle').onclick=()=>document.getElementById('editPanel').classList.toggle('open');
  document.getElementById('saveModal').onclick=()=>{ Object.assign(a,{title:mTitle.value,status:mStatus.value,rating:n(mRating.value),studio:mStudio.value,genres:mGenres.value.split(',').map(x=>x.trim()).filter(Boolean),rewatches:n(mRew.value),episodeCount:n(mEpisodes.value),cover:mCover.value,trailerUrl:mTrailer.value,notes:mNotes.value,synopsis:mSynopsis.value}); saveState(); detailModal.close(); renderCurrent(); };
  document.getElementById('deleteModal').onclick=()=>{ if(confirm('Delete this title?')){ state.anime=animeList().filter(x=>x.id!==id); saveState(); detailModal.close(); renderCurrent(); } };
  detailModal.showModal();
}

function addAnime(){
  const id = Math.max(...animeList().map(a=>a.id))+1;
  state.anime.push({id,finalRank:id,title:'New Anime',status:'Planned',rating:0,studio:'Unknown',genres:['Needs Edit'],rewatches:0,type:'TV',episodeCount:0,cover:'',synopsis:'New JoeAnimeDB entry.'});
  saveState(); openDetail(id);
}

function pickBestResult(results, title){
  if(!results?.length) return null;
  const wanted = cleanSearchTitle(title).toLowerCase();
  return results.find(item => [item.title,item.title_english,...(item.title_synonyms||[])].join(' ').toLowerCase().includes(wanted)) || results[0];
}
async function fetchJikanMetadata(a){
  const q = encodeURIComponent(cleanSearchTitle(a.title));
  const res = await fetch(`https://api.jikan.moe/v4/anime?q=${q}&limit=5&sfw=true`);
  if(!res.ok) throw new Error(res.status);
  const data = await res.json();
  const match = pickBestResult(data.data, a.title);
  if(!match) return null;
  return {malId:match.mal_id,officialTitle:match.title_english||match.title,cover:match.images?.jpg?.large_image_url||match.images?.jpg?.image_url||a.cover,trailerUrl:match.trailer?.url||a.trailerUrl,synopsis:match.synopsis||a.synopsis,type:match.type||a.type,year:match.year||a.year,episodeCount:match.episodes||a.episodeCount,communityScore:match.score||a.communityScore,source:match.source||a.source,duration:match.duration||a.duration,ratingText:match.rating||a.ratingText,studios:(match.studios||[]).map(s=>s.name),genres:[...(match.genres||[]),...(match.themes||[]),...(match.demographics||[])].map(g=>g.name)};
}
function applyMeta(a,m){
  if(!m) return false;
  Object.assign(a,{malId:m.malId||a.malId,officialTitle:m.officialTitle||a.officialTitle,cover:m.cover||a.cover,trailerUrl:m.trailerUrl||a.trailerUrl,synopsis:m.synopsis||a.synopsis,type:m.type||a.type,year:m.year||a.year,episodeCount:m.episodeCount||a.episodeCount,communityScore:m.communityScore||a.communityScore,source:m.source||a.source,duration:m.duration||a.duration,ratingText:m.ratingText||a.ratingText,metadataUpdatedAt:new Date().toISOString()});
  if(m.studios?.length) a.studio=m.studios.join(' / ');
  if(m.genres?.length) a.genres=[...new Set([...(a.genres||[]),...m.genres])].slice(0,8);
  return true;
}
function syncProgress(done,total,text){ syncOverlay.classList.remove('hidden'); syncStatus.textContent=text; syncFill.style.width=`${Math.round(done/total*100)}%`; }
async function syncMetadata(){
  if(!confirm('Fetch posters and metadata for all 108? This takes a few minutes.')) return;
  cancelSync=false; let updated=0, failed=0; const list=animeList();
  for(let i=0;i<list.length;i++){
    if(cancelSync) break;
    syncProgress(i,list.length,`Fetching ${i+1}/${list.length}: ${list[i].title}`);
    try{ if(applyMeta(list[i], await fetchJikanMetadata(list[i]))) updated++; } catch(e){ failed++; console.warn(e); }
    saveState(); await sleep(1250);
  }
  syncProgress(list.length,list.length,`Done. Updated ${updated}, failed ${failed}.`);
  saveState(); renderCurrent(); await sleep(1800); syncOverlay.classList.add('hidden');
}

document.addEventListener('DOMContentLoaded',()=>{
  document.body.className = localStorage.getItem('joeanime-theme') || '';
  document.querySelectorAll('#tabs button').forEach(b=>b.onclick=()=>{ currentView=b.dataset.view; if(currentView!=='watching') statusFilter='All'; renderCurrent(); });
  globalSearch.oninput=e=>{ searchText=e.target.value; currentView='rankings'; renderCurrent(); };
  closeModal.onclick=()=>detailModal.close();
  const exportBackup=()=>{ const blob=new Blob([JSON.stringify(state,null,2)],{type:'application/json'}); const a=document.createElement('a'); a.href=URL.createObjectURL(blob); a.download=`JoeAnimeDB-v2-backup-${new Date().toISOString().slice(0,10)}.json`; a.click(); URL.revokeObjectURL(a.href); };
  exportBtn.onclick=exportBackup; exportBtnSide.onclick=exportBackup;
  importFile.onchange=async e=>{ const f=e.target.files[0]; if(!f) return; const data=JSON.parse(await f.text()); if(!Array.isArray(data.anime)){alert('Not a JoeAnimeDB backup');return;} state=data; saveState(); renderCurrent(); };
  resetBtn.onclick=()=>{ if(confirm('Reset v2?')){ state=clone(seed); saveState(); renderCurrent(); } };
  randomBtn.onclick=()=>openDetail(animeList()[Math.floor(Math.random()*animeList().length)].id);
  syncBtn.onclick=syncMetadata; syncBtnTop.onclick=syncMetadata; cancelSyncBtn.onclick=()=>cancelSync=true;
  themeBtn.onclick=()=>document.body.classList.toggle('altTheme');
  renderCurrent();
});
