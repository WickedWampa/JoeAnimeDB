# JoeAnimeDB v3.1 Cinematic Polish

Open `index.html`.

## New v3.1 polish

- Animated page transitions
- Smoother poster/card hover effects
- Score badge pulse on hover
- Sidebar hover movement
- Richer Joe-specific achievements
- Related anime suggestions in detail pages
- More glassy desktop-app feel

Built on v3 App Core.
